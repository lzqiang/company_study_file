package com.ttpai.techshare.boot.hello;

import com.google.common.collect.Lists;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;

import java.util.ArrayList;

/**
 * Created by Kail on 2017/11/23.
 */

@SpringCloudApplication
public class Hello9002Application {

    public static void main(String[] args) {
        ArrayList<String> argsList = Lists.newArrayList(args);
        argsList.add("--server.port=9002");
        argsList.add("--spring.application.name=HELLO_APPLICATION");
        argsList.add("--eureka.client.serviceUrl.defaultZone=http://localhost:9000/eureka/");
        argsList.add("--eureka.instance.metadata-map.cluster=BOSS");

        SpringApplication.run(Hello9002Application.class, argsList.toArray(new String[argsList.size()]));
    }

}
