
# 配置

https://github.com/Netflix/Hystrix/wiki/Configuration