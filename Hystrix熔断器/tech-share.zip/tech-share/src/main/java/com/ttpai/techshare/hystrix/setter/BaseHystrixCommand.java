package com.ttpai.techshare.hystrix.setter;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandKey;
import com.ttpai.techshare.hystrix.Setters;

/**
 * Created by kail on 2017/11/26.
 */
public abstract class BaseHystrixCommand<T> extends HystrixCommand<T> {


    protected BaseHystrixCommand(String commandKey) {
        super(
                Setter.withGroupKey(Setters.HELLO_GROUP_KEY)
                        .andCommandKey(HystrixCommandKey.Factory.asKey(commandKey))
                        .andCommandPropertiesDefaults(Setters.commandSetter)
                        .andThreadPoolPropertiesDefaults(Setters.threadPoolSetter)
        );
    }

}
