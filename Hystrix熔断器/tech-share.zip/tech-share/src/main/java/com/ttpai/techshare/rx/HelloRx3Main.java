package com.ttpai.techshare.rx;

import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kail on 2017/11/19.
 */
public class HelloRx3Main {

    public static void main(String[] args) {
        Observable
                .create(new Observable.OnSubscribe<List<String>>() {

                    @Override
                    public void call(Subscriber<? super List<String>> subscriber) {
                        List<String> list = new ArrayList<>();
                        list.add("a");
                        list.add("bb");
                        list.add("ccc");
                        subscriber.onNext(list);
                    }
                })
                .flatMap(new Func1<List<String>, Observable<String>>() {

                    @Override
                    public Observable<String> call(List<String> strings) {
                        return Observable.from(strings);
                    }
                })
                .filter(new Func1<String, Boolean>() {
                    @Override
                    public Boolean call(String s) {
                        return s.startsWith("a");
                    }
                })
                .subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        System.out.println(s);
                    }
                });

    }


}
