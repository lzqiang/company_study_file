package com.ttpai.techshare.hystrix;

import com.netflix.hystrix.HystrixCommand;
import com.ttpai.techshare.hystrix.setter.BaseHystrixCommand;

/**
 * Created by kail on 2017/11/26.
 */
public class Main {

    public static void main(String[] args) {

        HystrixCommand<String> hystrixCommand = new BaseHystrixCommand<String>("hehe") {
            @Override
            protected String run() throws Exception {
                return null;
            }
        };

    }

}
