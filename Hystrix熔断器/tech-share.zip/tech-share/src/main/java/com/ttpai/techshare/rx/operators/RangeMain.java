package com.ttpai.techshare.rx.operators;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import rx.Observable;
import rx.Observer;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import java.net.URL;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by Kail on 2017/11/28.
 */
public class RangeMain {

    public static void testRxJavaWithoutBlocking(int count) throws Exception {
        CountDownLatch finishedLatch = new CountDownLatch(1);
        long t = System.nanoTime();
        Observable.range(0, count).map(i -> {
//            System.out.println(i);

            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("A:" + Thread.currentThread().getName());
            return 200;
        })
                .observeOn(Schedulers.computation())
                .subscribe(statusCode -> {
//            System.out.println(statusCode);
                    System.out.println("B:" + Thread.currentThread().getName());
                }, error -> {
                }, finishedLatch::countDown);
        finishedLatch.await();
        t = (System.nanoTime() - t) / 1000000; //ms
        System.out.println("RxJavaWithoutBlocking TPS: " + count * 1000 / t);
    }


    public static void testRxJavaWithFlatMap(int count) throws Exception {
        ExecutorService es = Executors.newFixedThreadPool(10, new ThreadFactoryBuilder().setNameFormat("SubscribeOn-%d").build());
        CountDownLatch finishedLatch = new CountDownLatch(1);
        long t = System.nanoTime();
        Observable
                .range(0, count)
                .subscribeOn(Schedulers.io())
                .flatMap(new Func1<Integer, Observable<?>>() {
                    @Override
                    public Observable<?> call(Integer integer) {
                        return Observable
                                .just(integer)
                                .subscribeOn(Schedulers.from(es))
                                .map(new Func1<Integer, Integer>() {
                                    @Override
                                    public Integer call(Integer integer) {
                                        try {
                                            TimeUnit.SECONDS.sleep(1);
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }

                                        System.out.println("A:" + Thread.currentThread().getName());
                                        return integer * integer;
                                    }
                                });
                    }
                })
                .observeOn(Schedulers.computation())
                .subscribe(
                        statusCode -> {
                            //System.out.println("C: " + Thread.currentThread().getName());
                        }, error -> {
                        }, finishedLatch::countDown
                );
        finishedLatch.await();
        t = (System.nanoTime() - t) / 1000000; //ms
        System.out.println("RxJavaWithFlatMap TPS: " + count * 1000 / t);
        es.shutdownNow();
    }

    public static void main(String[] args) throws Exception {
//        testRxJavaWithoutBlocking(1000);
        testRxJavaWithFlatMap(100);
        System.out.println("testRxJavaWithoutBlocking(10)");
    }

}
