package com.ttpai.techshare.semaphore;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Created by kail on 2017/11/5.
 */
public class SemaphoreDemo4 {

    private Semaphore semaphore = new Semaphore(1);

    public void doit() {
        try {
            if (semaphore.tryAcquire(10, TimeUnit.SECONDS)) {
                System.out.println(Thread.currentThread().getName() + " begin timer=" + System.currentTimeMillis());
                for (int i = 0; i < Integer.MAX_VALUE; i++) {
                }
                System.out.println(Thread.currentThread().getName() + "   end timer=" + System.currentTimeMillis());
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            semaphore.release();
        }
    }
}
