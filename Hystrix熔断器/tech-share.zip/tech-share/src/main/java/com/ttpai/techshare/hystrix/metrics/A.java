package com.ttpai.techshare.hystrix.metrics;

import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixCommandProperties;
import com.netflix.hystrix.HystrixEventType;
import com.netflix.hystrix.strategy.eventnotifier.HystrixEventNotifier;

import java.util.List;

/**
 * Created by kail on 2017/11/30.
 */
public class A extends HystrixEventNotifier {

    @Override
    public void markEvent(HystrixEventType eventType, HystrixCommandKey key) {
        super.markEvent(eventType, key);
        System.out.println("markEvent");
    }

    @Override
    public void markCommandExecution(HystrixCommandKey key, HystrixCommandProperties.ExecutionIsolationStrategy isolationStrategy, int duration, List<HystrixEventType> eventsDuringExecution) {
        super.markCommandExecution(key, isolationStrategy, duration, eventsDuringExecution);
        System.out.println("markCommandExecution");
    }
}
