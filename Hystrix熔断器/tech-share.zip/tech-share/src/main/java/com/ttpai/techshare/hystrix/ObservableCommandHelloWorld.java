package com.ttpai.techshare.hystrix;

import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixObservableCommand;
import rx.Observable;

public class ObservableCommandHelloWorld extends HystrixObservableCommand<String> {

    private final String name;

    public ObservableCommandHelloWorld(String name) {
        super(HystrixCommandGroupKey.Factory.asKey("ExampleGroup"));
        this.name = name;
    }


    @Override
    protected rx.Observable<String> construct() {
        return null;
    }


    public static void main(String[] args) {
        ObservableCommandHelloWorld commandHelloWorld = new ObservableCommandHelloWorld("World");
        Observable<String> construct = commandHelloWorld.construct();

    }

}