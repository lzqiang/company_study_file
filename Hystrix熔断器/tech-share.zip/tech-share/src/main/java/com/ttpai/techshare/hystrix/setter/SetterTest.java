package com.ttpai.techshare.hystrix.setter;

import com.netflix.hystrix.*;

/**
 * Created by kail on 2017/11/26.
 */
public class SetterTest {

    public void printInfo(HystrixCommand.Setter setter) {
        HystrixCommand<String> hystrixCommand = new HystrixCommand<String>(setter) {
            @Override
            protected String run() throws Exception {
                return null;
            }
        };

        System.out.println(hystrixCommand.getCommandGroup());
        System.out.println(hystrixCommand.getCommandKey());
        System.out.println(hystrixCommand.getThreadPoolKey());
    }


    public static void main(String[] args) {

        // groupKey 是必须的，代表一个线程组，往往是同一个业务模块的依赖调用在同一个线程池内
        HystrixCommandGroupKey groupKey = HystrixCommandGroupKey.Factory.asKey(SetterTest.class.getName());
        // commandKey 代表一个接口，默认是类的简单名
        HystrixCommandKey commandKey = HystrixCommandKey.Factory.asKey("mainMethod");
        // threadPoolKey 如果不设置默认是 groupKey
        HystrixThreadPoolKey threadPoolKey = HystrixThreadPoolKey.Factory.asKey(SetterTest.class.getName());

        HystrixCommand.Setter setter = HystrixCommand.Setter
                .withGroupKey(groupKey)
                .andCommandKey(commandKey)
                .andThreadPoolKey(threadPoolKey)

                .andCommandPropertiesDefaults(HystrixCommandProperties.Setter()
                        .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.THREAD)
                        .withExecutionTimeoutInMilliseconds(1000)
                        .withExecutionTimeoutEnabled(true)

                        .withCircuitBreakerEnabled(true)
                )
                .andThreadPoolPropertiesDefaults(HystrixThreadPoolProperties.Setter()
                        .withCoreSize(10)
                )
                ;

        SetterTest setterTest = new SetterTest();
        setterTest.printInfo(setter);

    }

}
