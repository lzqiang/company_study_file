package com.ttpai.techshare.other;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Kail on 2017/11/22.
 */
public class TimerMain {

    static Integer count = 0;

    static Date startDate;

    static {
        try {
            startDate = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse("2017/11/23 00:00:00");
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public static void schedule() {
        new Timer().schedule(new TimerTask() {
            public void run() {
                System.out.println("this is task you do6" + count++);
            }
        }, startDate, 2000);
    }


    public static void scheduleAtFixedRate() {
        new Timer().scheduleAtFixedRate(new TimerTask() {
            public void run() {
                System.out.println("this is task you do6" + count++);
            }
        }, startDate, 2000);
    }

    public static void main(String[] args) throws ParseException {
//        schedule();
        scheduleAtFixedRate();
    }
}
