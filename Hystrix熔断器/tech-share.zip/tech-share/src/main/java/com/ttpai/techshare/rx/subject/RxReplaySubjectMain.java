package com.ttpai.techshare.rx.subject;

import rx.functions.Action1;
import rx.subjects.ReplaySubject;

/**
 * Created by Kail on 2017/11/28.
 */
public class RxReplaySubjectMain {

    public static void main(String[] args) {
//        ReplaySubject<String> behaviorSubject = ReplaySubject.create(); // 默认 16 个初始化容量，貌似个无限个
        ReplaySubject<String> behaviorSubject = ReplaySubject.createWithSize(5); // 最大可以重放5个

        behaviorSubject.subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                System.out.println(s);
            }
        });

        for (int i = 0; i < 20; i++) {
            behaviorSubject.onNext(String.valueOf(i));
            if (i == 10) {
                behaviorSubject.subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        System.out.println("后来新加的监听：" + s);
                    }
                });
            }
        }
    }

}
