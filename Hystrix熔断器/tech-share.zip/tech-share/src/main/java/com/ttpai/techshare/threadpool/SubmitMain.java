package com.ttpai.techshare.threadpool;

import com.netflix.config.samples.SampleApplication;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.*;

/**
 * Created by kail on 2017/11/26.
 */
public class SubmitMain {

    public static void main(String[] args) throws ExecutionException, InterruptedException, TimeoutException {

        ExecutorService executorService = Executors.newFixedThreadPool(3);


        List<Future<String>> futures = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            Future<String> future = executorService.submit(new Callable<String>() {
                @Override
                public String call() throws Exception {
                    System.out.println(" 开始执行 " + Thread.currentThread().getName());
                    TimeUnit.SECONDS.sleep(3);
                    System.out.println(" 执行结束 " + Thread.currentThread().getName());
                    return "Hello";
                }
            });

            System.out.println("submit");
            futures.add(future);

//            System.out.println(future.get() + new Date());
        }

        System.out.println("添加完毕");

//
//        for (Future<String> future : futures) {
//            System.out.println(future.get(1, TimeUnit.SECONDS) + "===" + new Date());
//            System.out.println();
//        }


    }

}
