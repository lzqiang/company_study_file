package com.ttpai.techshare.boot.hello.keys;

import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixThreadPoolKey;

/**
 * Created by kail on 2017/11/25.
 */
public class Keys {

    public static void main(String[] args) {
        HystrixCommandKey heh = HystrixCommandKey.Factory.asKey("heh");

        HystrixCommandGroupKey asd = HystrixCommandGroupKey.Factory.asKey("asd");

        HystrixThreadPoolKey ad = HystrixThreadPoolKey.Factory.asKey("ad");
    }
}
