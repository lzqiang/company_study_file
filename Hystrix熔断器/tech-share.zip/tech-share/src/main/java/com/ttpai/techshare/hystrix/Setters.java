package com.ttpai.techshare.hystrix;

import com.netflix.hystrix.*;

/**
 * Created by kail on 2017/11/26.
 */
public class Setters {


    /**
     * 服务的名字
     */
    public static HystrixCommandGroupKey HELLO_GROUP_KEY = HystrixCommandGroupKey.Factory.asKey("HelloGroup");

    /**
     * 默认线程池设置
     */
    public static HystrixThreadPoolProperties.Setter threadPoolSetter = HystrixThreadPoolProperties.Setter()
            .withCoreSize(1)
            .withQueueSizeRejectionThreshold(1)
            //
            ;

    /**
     * 默认 command 设置
     */
    public static HystrixCommandProperties.Setter commandSetter = HystrixCommandProperties.Setter()
            // 信号量
            .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.SEMAPHORE)
            // 并发量1
            .withExecutionIsolationSemaphoreMaxConcurrentRequests(1)
            .withFallbackIsolationSemaphoreMaxConcurrentRequests(1)
            //
            // 滑动窗口中，最少要有多少个请求时，才触发开启短路, 如果设置为20（默认值），那么在一个10秒的滑动窗口内，如果只有19个请求，即使这19个请求都是异常的，也是不会触发开启短路器的
            .withCircuitBreakerErrorThresholdPercentage(1) // 20
            // 设置异常请求量的百分比，当异常请求达到这个百分比时，就触发打开短路器，默认是50，也就是50%
            .withCircuitBreakerRequestVolumeThreshold(1) // 50
            // 设置在短路之后，需要在多长时间内直接reject请求，然后在这段时间之后，再重新导holf-open状态，尝试允许请求通过以及自动恢复，默认值是5000毫秒
            .withCircuitBreakerSleepWindowInMilliseconds(100) // 5000
            //
            // 滑动窗口10s
            .withMetricsRollingStatisticalWindowInMilliseconds(10_000)
            // 分成10个桶，每个桶1秒
            .withMetricsRollingStatisticalWindowBuckets(10)
            //
            ;


    static {

    }
}
