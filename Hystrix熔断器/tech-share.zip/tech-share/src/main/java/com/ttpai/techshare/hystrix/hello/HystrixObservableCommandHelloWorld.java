package com.ttpai.techshare.hystrix.hello;

import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixObservableCommand;
import rx.Observable;
import rx.functions.Action1;

import java.io.IOException;

/**
 * Created by kail on 2017/11/29.
 */
public class HystrixObservableCommandHelloWorld extends HystrixObservableCommand<String> {


    private String name;

    protected HystrixObservableCommandHelloWorld(String name) {
        super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("HystrixObservableCommandHelloWorld")));
        this.name = name;
    }

    @Override
    protected Observable<String> construct() {
        return Observable.just(name);
    }

    public static void main(String[] args) throws IOException {

        HystrixObservableCommandHelloWorld observableCommandHelloWorld = new HystrixObservableCommandHelloWorld("Kail");

        observableCommandHelloWorld.observe()
//                .subscribeOn(Schedulers.newThread())
                .subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        System.out.println(s);
                    }
                });

//        System.in.read();
    }
}
