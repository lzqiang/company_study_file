package com.ttpai.techshare.rx;

import rx.Observable;
import rx.Observer;
import rx.functions.Action0;
import rx.functions.Action1;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Created by kail on 2017/11/26.
 */
public class HelloRx2ActionMain {

    public static void main(String[] args) throws ExecutionException, InterruptedException {


        Observable.just(1, 2, 3, 4)
                .subscribe(
                        new Action1<Integer>() {
                            @Override
                            public void call(Integer integer) {
                                System.out.println("Next: " + integer);
                            }
                        },
                        new Action1<Throwable>() {
                            @Override
                            public void call(Throwable throwable) {
                                System.out.println("Error: " + throwable);
                            }
                        }, new Action0() {
                            @Override
                            public void call() {
                                System.out.println("onCompleted");
                            }
                        }
                );

    }

}
