package com.ttpai.techshare.other;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

/**
 * Created by kail on 2017/11/12.
 */
public class SystemPropertiesMain {

    public static void main(String[] args) throws UnknownHostException {
        Properties properties = System.getProperties();
        properties.list(System.out);

        System.out.println();

        InetAddress address = InetAddress.getLocalHost();

        long start = System.currentTimeMillis();
        for (int i = 0; i < Integer.MAX_VALUE; i++) {
            address.getHostName();
        }
        System.out.println(System.currentTimeMillis() - start);
    }

}
