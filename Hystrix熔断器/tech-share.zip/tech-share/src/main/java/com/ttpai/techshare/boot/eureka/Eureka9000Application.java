package com.ttpai.techshare.boot.eureka;

import com.google.common.collect.Lists;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

import java.util.ArrayList;

@EnableEurekaServer
@SpringBootApplication
public class Eureka9000Application {

    public static void main(String[] args) {

        ArrayList<String> argsList = Lists.newArrayList(args);

        argsList.add("--server.port=9000");
        argsList.add("--spring.application.name=EUREKA");

        argsList.add("--eureka.client.serviceUrl.defaultZone=http://localhost:9000/eureka/");
        argsList.add("--eureka.instance.hostname=localhost");
        argsList.add("--eureka.instance.prefer-ip-address=true");


        SpringApplication.run(Eureka9000Application.class, argsList.toArray(new String[argsList.size()]));
    }
}