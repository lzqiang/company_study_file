package com.ttpai.techshare.hystrix.circuit;

import com.netflix.hystrix.*;
import com.ttpai.techshare.utils.NetRequestUtil;

import java.util.Iterator;
import java.util.concurrent.ExecutionException;

/**
 * Created by kail on 2017/11/26.
 */
public class ShortCircuitAndFailBackMain extends HystrixCommand<String> {

    /**
     * 默认 command 设置
     */
    public static HystrixCommandProperties.Setter commandSetter = HystrixCommandProperties.Setter()
            // 信号量
            .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.SEMAPHORE)
            // 并发量100
            .withExecutionIsolationSemaphoreMaxConcurrentRequests(100)
            //
            // 设置异常请求量的百分比，当异常请求达到这个百分比时，就触发打开短路器，默认是50，也就是50%
            .withCircuitBreakerRequestVolumeThreshold(10) // 50
            // 滑动窗口中，最少要有多少个请求时，才触发开启短路, 如果设置为20（默认值），那么在一个10秒的滑动窗口内，如果只有19个请求，即使这19个请求都是异常的，也是不会触发开启短路器的
            .withCircuitBreakerErrorThresholdPercentage(10) // 20
            // 设置在短路之后，需要在多长时间内直接reject请求，然后在这段时间之后，再重新导holf-open状态，尝试允许请求通过以及自动恢复，默认值是5000毫秒
            .withCircuitBreakerSleepWindowInMilliseconds(10000) // 5000
            .withCircuitBreakerEnabled(true)
//            .withCircuitBreakerForceOpen(true) // 强制打开
            ;

    private Boolean ex;

    public ShortCircuitAndFailBackMain(Boolean ex) {
        super(Setter
                .withGroupKey(HystrixCommandGroupKey.Factory.asKey("Hello"))
                .andCommandKey(HystrixCommandKey.Factory.asKey("hehe"))
                .andCommandPropertiesDefaults(commandSetter));
        this.ex = ex;
    }

    @Override
    protected String run() throws Exception {
        if (ex) {
            throw new Exception("ex");
        }
        return "ooooooooooook";
    }

    @Override
    protected String getFallback() {
        return "ex";
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException {


        for (int i = 0; i < 20; i++) {
            System.out.println(i + " : " + new ShortCircuitAndFailBackMain(i % 2 == 0).execute());
            NetRequestUtil.request(1000);

            Iterator<HystrixCommandMetrics> iterator = HystrixCommandMetrics.getInstances().iterator();

            for (; iterator.hasNext(); ) {
                HystrixCommandMetrics commandMetrics = iterator.next();
                if (commandMetrics.getCommandKey().name().equals("hehe")) {
                    System.out.println("    错误率：" + commandMetrics.getHealthCounts().getErrorPercentage());
                    System.out.println("    错误数：" + commandMetrics.getHealthCounts().getErrorCount());
                    System.out.println("    请求数：" + commandMetrics.getHealthCounts().getTotalRequests());
                    System.out.println("    熔断数：" + commandMetrics.getRollingCount(HystrixEventType.SHORT_CIRCUITED));
                }
            }

        }

        NetRequestUtil.request(10_000);

        for (int i = 0; i < 20; i++) {
            System.out.println(i + " : " + new ShortCircuitAndFailBackMain(false).execute());
            NetRequestUtil.request(1000);

            Iterator<HystrixCommandMetrics> iterator = HystrixCommandMetrics.getInstances().iterator();

            for (; iterator.hasNext(); ) {
                HystrixCommandMetrics commandMetrics = iterator.next();
                if (commandMetrics.getCommandKey().name().equals("hehe")) {
                    System.out.println("    错误率：" + commandMetrics.getHealthCounts().getErrorPercentage());
                    System.out.println("    错误数：" + commandMetrics.getHealthCounts().getErrorCount());
                    System.out.println("    请求数：" + commandMetrics.getHealthCounts().getTotalRequests());
                    System.out.println("    熔断数：" + commandMetrics.getRollingCount(HystrixEventType.SHORT_CIRCUITED));
                }
            }

        }

    }

}
