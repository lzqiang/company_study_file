package com.ttpai.techshare.rx.operators;

import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Func1;

import java.io.IOException;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * Created by Kail on 2017/11/28.
 */
public class Main {

    public static void main(String[] args) throws IOException {

        Observable
                .create(new Observable.OnSubscribe<String>() {
                    @Override
                    public void call(Subscriber<? super String> subscriber) {
                        for (int i = 0; i < 100; i++) {
                            long sleep = (long) (Math.random() * 100);
                            System.out.println(i + ":" + sleep);
                            try {
                                TimeUnit.MILLISECONDS.sleep(sleep);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            subscriber.onNext(i + "--" + new Date());
                        }
                    }
                })
//                .sample(1, TimeUnit.SECONDS) // throttleLast
                .throttleLast(1, TimeUnit.SECONDS) // sample
//                .throttleFirst(1, TimeUnit.SECONDS)
//                .debounce(50, TimeUnit.MILLISECONDS) // throttleWithTimeout
//                .throttleWithTimeout(50, TimeUnit.MILLISECONDS) // debounce
                .subscribe(new Observer<String>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onNext(String integer) {
                        System.out.println(integer);
                    }
                });
    }

}
