package com.ttpai.techshare.rx.operators;

import rx.Observable;
import rx.Subscriber;
import rx.functions.Action1;
import rx.functions.Func2;
import rx.observables.ConnectableObservable;
import rx.schedulers.Schedulers;

import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by Kail on 2017/11/28.
 */
public class ConcurrentRequestMain2 {

    private void s() {
        ConnectableObservable<String> stringObservable = Observable.from(Arrays.asList("1", "2", "3"))
                .flatMap((String s) -> {
                    return Observable.just(s).subscribeOn(Schedulers.computation());
                })
                .publish();

        stringObservable
                .flatMap(s -> {
                    // do More asyncStuff depending on subscription
                    return Observable.just(s).subscribeOn(Schedulers.newThread());
                })
                .subscribe(s -> {
                    // use result here
                    System.out.println(s + "sss");
                });

        stringObservable
                .subscribe(s -> {
                    // use immediate result here.
                    System.out.println(s);
                });

        stringObservable.connect();
    }

    public static void main(String[] args) {

        ExecutorService executorService = Executors.newFixedThreadPool(3);

        Observable<String> stringObservable = Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                System.out.println("开始" + new Date());
                try {
                    TimeUnit.SECONDS.sleep(2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                subscriber.onNext("结束" + new Date());
                subscriber.onCompleted();
            }

        }).subscribeOn(Schedulers.from(executorService));

        Observable<String> stringObservable1 = Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                System.out.println("开始2" + new Date());
                try {
                    TimeUnit.SECONDS.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                subscriber.onNext("结束2" + new Date());
                subscriber.onCompleted();
            }

        }).subscribeOn(Schedulers.from(executorService));


        Observable<String> stringObservable2 = Observable
                .zip(stringObservable, stringObservable1, new Func2<String, String, String>() {
                    @Override
                    public String call(String s, String s2) {
                        return s + "--" + s2 + "--" + new Date();
                    }
                })
                .doOnNext(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        System.out.println(s);
                    }
                });

        System.out.println("111");
        stringObservable2.toCompletable().await();
        System.out.println("333");
        executorService.shutdown();


    }
}
