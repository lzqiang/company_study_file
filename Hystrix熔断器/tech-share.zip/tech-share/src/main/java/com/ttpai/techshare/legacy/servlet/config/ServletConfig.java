package com.ttpai.techshare.legacy.servlet.config;

import com.netflix.hystrix.contrib.metrics.eventstream.HystrixMetricsStreamServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.ttpai.techshare.legacy.servlet.servlet.TestServlet1;
import com.ttpai.techshare.legacy.servlet.servlet.TestServlet2;

/**
 * Created by kail on 2017/11/25.
 */
@Configuration
public class ServletConfig {

    @Bean
    public TestServlet1 testServlet1() {
        return new TestServlet1();
    }


    @Bean
    public ServletRegistrationBean registrationTestServlet1(TestServlet1 servlet) {
        ServletRegistrationBean registrationBean = new ServletRegistrationBean();
        registrationBean.setServlet(servlet);
        registrationBean.addUrlMappings("/servlet1");
        return registrationBean;
    }

    // ========================================================

    @Bean
    public TestServlet2 testServlet2() {
        return new TestServlet2();
    }


    @Bean
    public ServletRegistrationBean registrationTestServlet2(TestServlet2 servlet) {
        ServletRegistrationBean registrationBean = new ServletRegistrationBean();
        registrationBean.setServlet(servlet);
        registrationBean.addUrlMappings("/servlet2");
        return registrationBean;
    }

    // ========================================================


    @Bean
    public HystrixMetricsStreamServlet hystrixMetricsStreamServlet() {
        return new HystrixMetricsStreamServlet();
    }


    @Bean
    public ServletRegistrationBean registrationHystrixMetricsStreamServlet(HystrixMetricsStreamServlet servlet) {
        ServletRegistrationBean registrationBean = new ServletRegistrationBean();
        registrationBean.setServlet(servlet);
        registrationBean.addUrlMappings("/hystrix.stream");
        return registrationBean;
    }


}
