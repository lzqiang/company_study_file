package com.ttpai.techshare.rx.subject;

import rx.functions.Action1;
import rx.subjects.BehaviorSubject;

/**
 * Created by Kail on 2017/11/28.
 */
public class RxBehaviorSubjectMain {

    public static void main(String[] args) {
        BehaviorSubject<String> behaviorSubject = BehaviorSubject.create();

        behaviorSubject.subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                System.out.println(s);
            }
        });

        for (int i = 0; i < 20; i++) {
            behaviorSubject.onNext(String.valueOf(i));
            if (i == 10) {
                behaviorSubject.subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        System.out.println("后来新加的监听：" + s);
                    }
                });
            }
        }
    }

}
