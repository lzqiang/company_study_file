package com.ttpai.techshare.rx.operators.creating;


import rx.Observable;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by Kail on 2017/11/28.
 */
public class RxIntervalMain {

    public static void main(String[] args) throws IOException {

        ExecutorService executorService = Executors.newFixedThreadPool(3);

        Observable<Long> observable = Observable
                .interval(1, TimeUnit.SECONDS, Schedulers.from(executorService))
                ;


        observable.subscribe(new Action1<Long>() {
            @Override
            public void call(Long aLong) {
                System.out.println("1");
            }
        });



        observable.subscribe(new Action1<Long>() {
            @Override
            public void call(Long aLong) {
                System.out.println("2");
            }
        });

        System.in.read();

    }

}
