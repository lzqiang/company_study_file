package com.ttpai.techshare.rx.subject;

import rx.Observer;
import rx.Subscription;
import rx.functions.Action1;
import rx.subjects.PublishSubject;

/**
 * Created by Kail on 2017/11/28.
 */
public class RxPublishSubjectMain {

    public static void main(String[] args) {
        PublishSubject<String> stringPublishSubject = PublishSubject.create();

        stringPublishSubject.subscribe(new Observer<String>() {
            @Override
            public void onCompleted() {
                System.out.println("Observable completed");
            }

            @Override
            public void onError(Throwable e) {
                System.out.println("Oh,no!Something wrong happened!");
            }

            @Override
            public void onNext(String message) {
                System.out.println(message);
            }
        });

        stringPublishSubject.subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                System.out.println("s:" + s);
            }
        });

        stringPublishSubject.subscribe();

        stringPublishSubject.onNext("Hello World");
        stringPublishSubject.onNext("Hello World1");
        stringPublishSubject.onNext("Hello World2");
        stringPublishSubject.onNext("Hello World3");

    }

}
