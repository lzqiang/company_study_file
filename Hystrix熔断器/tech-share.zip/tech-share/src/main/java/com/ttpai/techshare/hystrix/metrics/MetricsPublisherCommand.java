package com.ttpai.techshare.hystrix.metrics;

import com.netflix.hystrix.*;
import com.netflix.hystrix.strategy.metrics.HystrixMetricsPublisher;
import com.netflix.hystrix.strategy.metrics.HystrixMetricsPublisherCommand;
import com.netflix.hystrix.strategy.metrics.HystrixMetricsPublisherCommandDefault;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by kail on 2017/11/30.
 */
public class MetricsPublisherCommand extends HystrixMetricsPublisherCommandDefault {


    public MetricsPublisherCommand(HystrixCommandKey commandKey, HystrixCommandGroupKey commandGroupKey, HystrixCommandMetrics metrics, HystrixCircuitBreaker circuitBreaker, HystrixCommandProperties properties) {
        super(commandKey, commandGroupKey, metrics, circuitBreaker, properties);
        System.out.println(metrics.getCurrentConcurrentExecutionCount());

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                System.out.println(metrics.getExecutionTimeMean());
                System.out.println(metrics.getHealthCounts().getErrorCount());
                System.out.println(metrics.getHealthCounts().getTotalRequests());
                System.out.println(metrics.getProperties().executionIsolationStrategy());
            }
        }, 0, 1000);


    }

    @Override
    public void initialize() {
        super.initialize();
        System.out.println("initialize");
    }
}
