package com.ttpai.techshare.hystrix.hello;

import com.netflix.hystrix.*;
import com.ttpai.techshare.utils.NetRequestUtil;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeoutException;

public class HystrixCommand4ConcurrentSetter extends HystrixCommand<String> {

    private final String name;

    public HystrixCommand4ConcurrentSetter(String name) {
        super(
                Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("HystrixCommandHelloWorld"))
                        .andCommandKey(HystrixCommandKey.Factory.asKey("main"))

                        .andCommandPropertiesDefaults(
                                HystrixCommandProperties.Setter()
                                        .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.SEMAPHORE)
                                        .withExecutionIsolationSemaphoreMaxConcurrentRequests(4) // 对 THREAD 不起作用
                        )

        );
        this.name = name;
    }

    @Override
    protected String run() {
        // 假设这里是一个 第三方 的 网络调用，比较耗时
        NetRequestUtil.request(200);

        return "Hello " + name + "!";
    }

    @Override
    protected String getFallback() {
        return "Hello Default";
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException, TimeoutException, IOException {

        ExecutorService executorService = Executors.newFixedThreadPool(4);
        for (int i = 0; i < 10; i++) {
            executorService.execute(new Runnable() {
                @Override
                public void run() {
                    String result = new HystrixCommand4ConcurrentSetter("Kail").execute(); // cmd.queue().get()
                    System.out.println(result);
                }
            });
//            NetRequestUtil.sleep(100);
        }
        executorService.shutdown();

    }
}
