package com.ttpai.techshare.other.observer;

import java.util.Observable;

/**
 * Created by kail on 2017/11/6.
 */
public class SubmitObservable extends Observable {

    public void ido() {
        super.setChanged();

        System.out.println("SubmitObservable： 开始干活了");

        super.notifyObservers("干活");
    }

}
