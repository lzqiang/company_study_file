package com.ttpai.techshare.hystrix.hello;

import com.netflix.hystrix.*;
import com.ttpai.techshare.utils.NetRequestUtil;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public class HystrixCommand3TimeoutSetter extends HystrixCommand<String> {

    private final String name;

    public HystrixCommand3TimeoutSetter(String name) {
        super(
                Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("HystrixCommandHelloWorld"))
                        .andCommandKey(HystrixCommandKey.Factory.asKey("main"))
                        .andCommandPropertiesDefaults(
                                HystrixCommandProperties.Setter()
                                        .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.SEMAPHORE)
//                                        .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.THREAD)
                                        .withExecutionTimeoutInMilliseconds(3000)
//                                        .withExecutionTimeoutEnabled(false)
                        )

        );
        this.name = name;
    }

    @Override
    protected String run() {
        // 假设这里是一个 第三方 的 网络调用，比较耗时
        System.out.println("start");
        NetRequestUtil.request(1500); // 变动在这里，改为1500
        System.out.println("end");

        return "Hello " + name + "!";
    }

//    @Override
//    protected String getFallback() {
//        return "Hello Default";
//    }

    public static void main(String[] args) throws ExecutionException, InterruptedException, TimeoutException, IOException {
        String result = new HystrixCommand3TimeoutSetter("Kail").execute(); // cmd.queue().get()
        System.out.println(result);

    }
}
