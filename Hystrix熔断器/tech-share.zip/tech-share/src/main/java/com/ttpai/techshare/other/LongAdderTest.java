package com.ttpai.techshare.other;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

/**
 * Created by Kail on 2017/11/23.
 */
public class LongAdderTest {

    static LongAdder longAdder = new LongAdder();
    static AtomicLong atomicLong = new AtomicLong();

    static int THREAD_COUNT = 100;
    static int FOR_COUNT = 1000_0000;

    static CountDownLatch countDownLatch = new CountDownLatch(THREAD_COUNT);

    private static void testLongAdder() throws InterruptedException {
        countDownLatch = new CountDownLatch(THREAD_COUNT);
        for (int i = 0; i < 100_0000; i++) {
            longAdder.add(1);
        }

        System.out.println(longAdder);

        for (int i = 0; i < THREAD_COUNT; i++) {
            new Thread(() -> {
                for (int i1 = 0; i1 < FOR_COUNT; i1++) {
                    longAdder.add(1);
                }
                countDownLatch.countDown();
            }).start();
        }
        countDownLatch.await();

        System.out.println(longAdder);
    }

    private static void testAtomicLong() throws InterruptedException {
        countDownLatch = new CountDownLatch(THREAD_COUNT);
        for (int i = 0; i < 100_0000; i++) {
            atomicLong.addAndGet(1);
        }

        System.out.println(atomicLong);


        for (int i = 0; i < THREAD_COUNT; i++) {
            new Thread(() -> {
                for (int i1 = 0; i1 < FOR_COUNT; i1++) {
                    atomicLong.addAndGet(1);
                }
                countDownLatch.countDown();
            }).start();
        }

        countDownLatch.await();

        System.out.println(atomicLong);
    }

    public static void main(String[] args) throws InterruptedException {
        long start = System.currentTimeMillis();
        testLongAdder();
        System.out.println(System.currentTimeMillis() - start);

        start = System.currentTimeMillis();
        testAtomicLong();
        System.out.println(System.currentTimeMillis() - start);

    }

}
