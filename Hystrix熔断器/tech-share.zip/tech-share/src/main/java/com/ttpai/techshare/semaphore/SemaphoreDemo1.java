package com.ttpai.techshare.semaphore;

import com.ttpai.techshare.utils.NetRequestUtil;

import java.util.concurrent.Semaphore;

/**
 * Created by kail on 2017/11/5.
 */
public class SemaphoreDemo1 {

    private Semaphore semaphore = new Semaphore(2);

    public void doit() {
        try {
            semaphore.acquire();
            System.out.println(Thread.currentThread().getName() + " begin timer=" + System.currentTimeMillis());
            NetRequestUtil.request(3000);
            System.out.println(Thread.currentThread().getName() + "   end timer=" + System.currentTimeMillis());

        } catch (InterruptedException e) {
            System.out.println("线程" + Thread.currentThread().getName() + "进入了catch");
            e.printStackTrace();
        } finally {
            semaphore.release();
        }
    }
}
