package com.ttpai.techshare.rx;

import rx.Observable;
import rx.Observer;
import rx.Subscriber;

import java.util.concurrent.TimeUnit;

/**
 * Created by kail on 2017/11/19.
 */
public class HelloRx1CreateMain {

    public static void main(String[] args) {
        /*
         * 发送者
         */
        Observable<String> sender = Observable.create(new Observable.OnSubscribe<String>() {

            @Override
            public void call(Subscriber<? super String> subscriber) {
                subscriber.onNext("How are you ！");

                try {
                    TimeUnit.SECONDS.sleep(5);
                } catch (InterruptedException e) {
                    subscriber.onError(e);
                }

                subscriber.onNext("I am fine, Thank you ！And you ?");

                subscriber.onCompleted();
            }
        });

        // ========

        Observer<String> receiver = new Observer<String>() {

            @Override
            public void onCompleted() {
                //数据接收完成时调用
                System.out.println("onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                //发生错误调用
                System.out.println("onError");
            }

            @Override
            public void onNext(String s) {
                //正常接收数据调用
                System.out.println("onNext: " + s);
            }
        };

        // =====
        sender.subscribe(receiver);


        System.out.println("over !");

    }


}
