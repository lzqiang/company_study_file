package com.ttpai.techshare.utils;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 针对 httpclient 4
 * <p>
 * 依赖项： <b style="color:red">org.apache.httpcomponents:httpmime</b>
 */
public class HttpClient4Util {

    //连接超时的时间
    private static final int TIMEOUT_SOCKET = 1000;

    //请求获取数据的超时时间，单位毫秒。 如果访问一个接口，多少时间内无法返回数据，就直接放弃此次调用。
    private static final int TIMEOUT_CONNECTION = 2000;

    private static final Charset UTF8 = StandardCharsets.UTF_8;

    private RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(TIMEOUT_SOCKET).setConnectTimeout(TIMEOUT_CONNECTION).build();

    /**
     * 默认httpclient，超时时间socket 1 秒，connection 2 秒
     */
    public static final HttpClient4Util DEFAULT_CLIENT = newInstance(TIMEOUT_CONNECTION, TIMEOUT_SOCKET);

    public static HttpClient4Util newInstance(int connectionTimeOut, int socketTimeOut) {
        HttpClient4Util httpClient4Util = new HttpClient4Util();
        httpClient4Util.requestConfig = RequestConfig.custom().setSocketTimeout(socketTimeOut).setConnectTimeout(connectionTimeOut).build();
        return httpClient4Util;
    }

    private HttpClient4Util() {
    }

    /**
     * 发送 get 请求
     *
     * @param httpUrl 请求地址
     */
    public String get(String httpUrl) throws IOException {
        HttpGet httpGet = new HttpGet(httpUrl);
        return request(httpGet);
    }

    /**
     * 发送 post请求
     *
     * @param httpUrl 地址
     */
    public String post(String httpUrl) throws IOException {
        HttpPost httpPost = new HttpPost(httpUrl);
        return request(httpPost);
    }

    /**
     * 发送 post请求
     *
     * @param httpUrl 地址
     * @param params  参数(格式:key1=value1&key2=value2)
     */
    public String post(String httpUrl, String params) throws IOException {
        HttpPost httpPost = new HttpPost(httpUrl);// 创建httpPost

        //设置参数
        StringEntity stringEntity = new StringEntity(params, UTF8);
        stringEntity.setContentType("application/x-www-form-urlencoded");
        httpPost.setEntity(stringEntity);

        return request(httpPost);
    }

    /**
     * 发送 post请求
     *
     * @param httpUrl 地址
     * @param params  参数
     */
    public String post(String httpUrl, Map<String, String> params) throws IOException {
        HttpPost httpPost = new HttpPost(httpUrl);// 创建httpPost

        // 创建参数队列
        List<NameValuePair> nameValuePairs = new ArrayList<>();
        for (String key : params.keySet()) {
            nameValuePairs.add(new BasicNameValuePair(key, params.get(key)));
        }
        httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs, UTF8));

        return request(httpPost);
    }


    private String request(HttpRequestBase requestBase) throws IOException {
        requestBase.setConfig(requestConfig); // 创建默认的httpClient实例.

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            try (CloseableHttpResponse response = httpClient.execute(requestBase);) {
                HttpEntity entity = response.getEntity();
                return EntityUtils.toString(entity, UTF8);
            }
        }
    }
}
