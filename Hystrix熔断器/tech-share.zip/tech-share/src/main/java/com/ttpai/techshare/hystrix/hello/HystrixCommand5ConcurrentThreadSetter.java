package com.ttpai.techshare.hystrix.hello;

import com.netflix.hystrix.*;
import com.ttpai.techshare.utils.NetRequestUtil;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeoutException;

public class HystrixCommand5ConcurrentThreadSetter extends HystrixCommand<String> {

    private final String name;

    public HystrixCommand5ConcurrentThreadSetter(String name) {
        super(
                Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("HystrixCommandHelloWorld"))
                        .andCommandKey(HystrixCommandKey.Factory.asKey("main"))

                        .andCommandPropertiesDefaults(
                                HystrixCommandProperties.Setter()
                                        .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.THREAD)
                        )

                        .andThreadPoolPropertiesDefaults(
                                HystrixThreadPoolProperties.Setter()
                                        .withCoreSize(2)
                                        .withAllowMaximumSizeToDivergeFromCoreSize(true)
                                        .withMaximumSize(2) // withAllowMaximumSizeToDivergeFromCoreSize 为true 的时候生效

                                        .withMaxQueueSize(100)
                                        .withQueueSizeRejectionThreshold(5)
                        )

        );
        this.name = name;
    }

    @Override
    protected String run() {
        // 假设这里是一个 第三方 的 网络调用，比较耗时
        NetRequestUtil.request(500);

        return "Hello " + name + "!";
    }

    @Override
    protected String getFallback() {
        return "Hello Default";
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException, TimeoutException, IOException {


        ExecutorService executorService = Executors.newFixedThreadPool(40);
        for (int i = 0; i < 10; i++) {
            executorService.execute(new Runnable() {
                @Override
                public void run() {
                    String result = new HystrixCommand5ConcurrentThreadSetter("Kail").execute(); // cmd.queue().get()
                    System.out.println(result);
                }
            });
        }

        executorService.shutdown();


    }
}
