package com.ttpai.techshare.rx.opt;


import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import java.io.IOException;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by kail on 2017/11/28.
 */
public class HelloRxMapMain {

    public static void main(String[] args) throws IOException {
        Observable.just(1, 2, 3, 4, 5)
                .subscribeOn(Schedulers.from(Executors.newFixedThreadPool(3)))
                .map(new Func1<Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer) {
                        try {
                            TimeUnit.SECONDS.sleep(1);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return integer + 1;
                    }
                })
                .subscribeOn(Schedulers.from(Executors.newFixedThreadPool(3)))
                .map(new Func1<Integer, Integer>() {
                    @Override
                    public Integer call(Integer integer) {
                        try {
                            TimeUnit.SECONDS.sleep(2);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return integer * 2;
                    }
                })
//                .subscribeOn(Schedulers.io())
//                .subscribeOn(Schedulers.newThread())
//                .subscribeOn(Schedulers.from(Executors.newFixedThreadPool(3)))
//                .subscribeOn(Schedulers.trampoline())
//
//                .observeOn(Schedulers.from(Executors.newFixedThreadPool(3)))
                .observeOn(Schedulers.io())
                .subscribe(new Subscriber<Integer>() {

                    @Override
                    public void onNext(Integer integer) {
                        try {
                            TimeUnit.SECONDS.sleep(2);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        System.out.println(integer + "  " + new Date());
                    }

                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                });

        System.in.read();
    }

}
