package com.ttpai.techshare.boot.turbine;

import com.google.common.collect.Lists;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.turbine.EnableTurbine;

import java.util.ArrayList;

/**
 * turbine.app-config=
 * turbine.app-config-list=
 * turbine.cluster-name-expression=
 * turbine.combine-host-port=true
 * <p>
 * Created by Kail on 2017/11/23.
 */
@EnableTurbine
@SpringBootApplication
public class Turbine9902App {

    public static void main(String[] args) {
        ArrayList<String> argsList = Lists.newArrayList(args);
        argsList.add("--server.port=9902");
        argsList.add("--spring.application.name=TURBINE");
        argsList.add("--eureka.client.serviceUrl.defaultZone=http://localhost:9000/eureka/");
        argsList.add("--turbine.app-config=HELLO_APPLICATION");
        argsList.add("--turbine.clusterNameExpression='default'");

//        argsList.add("--turbine.clusterNameExpression=metadata['cluster']");
//        argsList.add("--turbine.aggregator.cluster-config=BOSS");

        SpringApplication.run(Turbine9902App.class, argsList.toArray(new String[argsList.size()]));
    }
}
