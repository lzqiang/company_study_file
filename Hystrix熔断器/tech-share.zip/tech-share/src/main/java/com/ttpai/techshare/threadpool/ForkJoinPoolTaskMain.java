package com.ttpai.techshare.threadpool;


import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.TimeUnit;

/**
 * Java 多线程中的任务分解机制-ForkJoinPool详解
 * http://blog.csdn.net/a369414641/article/details/48350795
 * <p>
 * 聊聊并发（八）——Fork/Join框架介绍
 * http://www.infoq.com/cn/articles/fork-join-introduction/
 * <p>
 * Created by kail on 2017/11/26.
 */
public class ForkJoinPoolTaskMain {


    /**
     * 定义一个可分解的的任务类，继承了RecursiveAction抽象类
     * 必须实现它的compute方法
     */
    public static class MyTask extends RecursiveTask<Integer> {

        private Integer THRESHOLD = 10; // 一个线程最多计算10个数字

        private Integer start;
        private Integer end;

        public MyTask(Integer start, Integer end) {
            this.start = start;
            this.end = end;
        }

        @Override
        protected Integer compute() {

            int computeCnt = end - start;
            int half = (end + start) / 2;

            if (computeCnt > THRESHOLD) {

                MyTask myTaskLeft = new MyTask(start, half);
                MyTask myTaskRight = new MyTask(half + 1, end);

                // 执行子任务
                myTaskLeft.fork();
                System.out.println("half" + half);
                myTaskRight.fork();
                System.out.println("half" + half);
                System.out.println();
                // 子任务执行完

                Integer myTaskLeftResult = myTaskLeft.join();
                Integer myTaskRightResult = myTaskRight.join();

                // 合并子任务
                return myTaskLeftResult + myTaskRightResult;

            } else {
                int sum = 0;
                for (int i = start; i <= end; i++) {
                    sum += i;
                }
                try {
                    System.out.println(Thread.currentThread().getName() + "  sleep");
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return sum;

            }
        }

    }

    public static void main(String[] args) throws Exception {
        //创建一个支持分解任务的线程池ForkJoinPool
        ForkJoinPool pool = new ForkJoinPool();

        MyTask task = new MyTask(1, 100);
        ForkJoinTask<Integer> forkJoinTask = pool.submit(task);
        System.out.println(forkJoinTask.get());
    }

}
