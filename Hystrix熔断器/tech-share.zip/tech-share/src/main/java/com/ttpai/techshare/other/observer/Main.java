package com.ttpai.techshare.other.observer;

/**
 * http://blog.csdn.net/bearray123/article/details/6175480
 * <p>
 * Created by kail on 2017/11/6.
 */
public class Main {


    public static void main(String[] args) throws InterruptedException {

        SubmitObservable submitObservable = new SubmitObservable();
        submitObservable.addObserver(new HelloObserve());
        submitObservable.addObserver(new WorldObserve());

        submitObservable.ido();
        System.out.println();
        System.out.println();
        submitObservable.ido();


    }

}
