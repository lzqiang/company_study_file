package com.ttpai.techshare.boot.dashboard;

import com.google.common.collect.Lists;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;

import java.util.ArrayList;

/**
 * http://localhost:9901/hystrix
 */
@SpringBootApplication
@EnableHystrixDashboard
public class Dashboard9901App {

    public static void main(String[] args) {
        ArrayList<String> argsList = Lists.newArrayList(args);
        argsList.add("--server.port=9901");

        SpringApplication.run(Dashboard9901App.class, argsList.toArray(new String[argsList.size()]));
    }
}
