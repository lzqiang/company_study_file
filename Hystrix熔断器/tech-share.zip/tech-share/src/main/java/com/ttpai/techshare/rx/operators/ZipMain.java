package com.ttpai.techshare.rx.operators;

import rx.Observable;
import rx.Observer;
import rx.Scheduler;
import rx.Subscriber;
import rx.functions.Func2;
import rx.schedulers.Schedulers;

import java.util.Date;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Created by Kail on 2017/11/28.
 */
public class ZipMain {

    public static void main(String[] args) throws InterruptedException {

        Observable<String> stringObservable = Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                System.out.println("开始" + new Date());
                try {
                    TimeUnit.SECONDS.sleep(2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                subscriber.onNext("结束" + new Date());
                subscriber.onCompleted();
            }

        });

        Observable<String> stringObservable1 = Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                System.out.println("开始2" + new Date());
                try {
                    TimeUnit.SECONDS.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                subscriber.onNext("结束2" + new Date());
                subscriber.onCompleted();
            }

        });

        CountDownLatch finishedLatch = new CountDownLatch(2);

        Observable
                .zip(stringObservable, stringObservable1, new Func2<String, String, String>() {
                    @Override
                    public String call(String s, String s2) {
                        return s + "   " + s2;
                    }
                })
                .subscribeOn(Schedulers.newThread())
                .subscribe(new Subscriber<String>() {

                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onNext(String s) {
                        System.out.println(s);
                    }

                    @Override
                    public void onCompleted() {
                        finishedLatch.countDown();
                        System.out.println(" finishedLatch.countDown();");
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        finishedLatch.countDown();
                        System.out.println("finishedLatch.countDown();");
                    }

                });

        finishedLatch.await();
        System.out.println("finishedLatch.await();");

    }

}
