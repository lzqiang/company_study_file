
- [Subject = Observable + Observer](http://wiki.jikexueyuan.com/project/rxjava/chapter2/subject_observable_observer.html)


RxJava提供四种不同的Subject：

- PublishSubject
- BehaviorSubject
- ReplaySubject
- AsyncSubject