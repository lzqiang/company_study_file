package com.ttpai.techshare.legacy.servlet.controller;

import com.netflix.hystrix.HystrixCommandMetrics;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by kail on 2017/11/25.
 */
@RestController
@RequestMapping("/servlet")
public class ServletController {

    @RequestMapping("/index")
    public List<HystrixCommandMetrics.HealthCounts> index() {
        List<HystrixCommandMetrics.HealthCounts> result = new ArrayList<>();

        Iterator<HystrixCommandMetrics> iterator = HystrixCommandMetrics.getInstances().iterator();
        for (; iterator.hasNext(); ) {
            HystrixCommandMetrics next = iterator.next();
            HystrixCommandMetrics.HealthCounts healthCounts = next.getHealthCounts();
            result.add(healthCounts);
        }
        return result;
    }

}
