package com.ttpai.techshare.rx.operators.creating;

import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.observables.ConnectableObservable;

/**
 * Created by Kail on 2017/11/28.
 */
public class Main {

    public static void main(String[] args) {
        ConnectableObservable
                .create(new Observable.OnSubscribe<Object>() {
                    @Override
                    public void call(Subscriber<? super Object> subscriber) {
                        System.out.println("asda");
                        subscriber.onNext("asd");
                    }
                })
                .subscribe(new Observer<Object>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onNext(Object o) {
                        System.out.println(o);
                    }
                });
    }

}
