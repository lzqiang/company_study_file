package com.ttpai.techshare.rx;

import org.springframework.scheduling.annotation.Schedules;
import rx.Observable;
import rx.Observer;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Created by kail on 2017/11/26.
 */
public class HelloRx2JustMain {

    public static void main(String[] args) throws ExecutionException, InterruptedException {


        Observable.just(1, 2, 3, 4).subscribe(new Observer<Integer>() {

            @Override
            public void onNext(Integer integer) {
                System.out.println("onNext: " + integer);

                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    onError(e);
                }
                System.out.println("onNext End: " + integer);
            }

            @Override
            public void onCompleted() {
                System.out.println("onCompleted");
            }

            @Override
            public void onError(Throwable throwable) {
                System.out.println("onError");
            }


        });

    }

}
