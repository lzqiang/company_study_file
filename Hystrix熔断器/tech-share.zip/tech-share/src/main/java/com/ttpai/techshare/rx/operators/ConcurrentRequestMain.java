package com.ttpai.techshare.rx.operators;

import rx.Observable;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 并发
 * Created by Kail on 2017/11/28.
 */
public class ConcurrentRequestMain {

    public static void testRxJavaWithFlatMap(int count) throws Exception {
        ExecutorService es = Executors.newFixedThreadPool(200);
        CountDownLatch finishedLatch = new CountDownLatch(1);
        long t = System.nanoTime();
        Observable.range(0, count).subscribeOn(Schedulers.io()).flatMap(i -> {
                    //System.out.println("A: " + Thread.currentThread().getName());
                    return Observable.just(i).subscribeOn(Schedulers.from(es)).map(v -> {
                        /**
                         * 耗时的操作
                         */
                        return v;
                    });
                }
        ).observeOn(Schedulers.computation()).subscribe(statusCode -> {
            //System.out.println("C: " + Thread.currentThread().getName());
        }, error -> {
        }, () -> {
            finishedLatch.countDown();
        });
        finishedLatch.await();
        t = (System.nanoTime() - t) / 1000000; //ms
        System.out.println("RxJavaWithFlatMap TPS: " + count * 1000 / t);
        es.shutdownNow();
    }


    public static void testRxJavaWithParallel(int count) throws Exception {
        ExecutorService es = Executors.newFixedThreadPool(200);
        CountDownLatch finishedLatch = new CountDownLatch(count);
        long t = System.nanoTime();
        for (int k = 0; k < count; k++) {
            Observable.just(k).map(i -> {
                //System.out.println("A: " + Thread.currentThread().getName());
                /**
                 * 耗时的操作
                 */
                return i;
            })
                    .subscribeOn(Schedulers.from(es))
                    .observeOn(Schedulers.computation())
                    .subscribe(
                            statusCode -> {
                            }
                            , error -> {
                            }
                            , finishedLatch::countDown
                    );
        }
        finishedLatch.await();
        t = (System.nanoTime() - t) / 1000000; //ms
        System.out.println("RxJavaWithParallel TPS: " + count * 1000 / t);
        es.shutdownNow();
    }

    public static void main(String[] args) throws Exception {
        testRxJavaWithParallel(100);
    }

}
