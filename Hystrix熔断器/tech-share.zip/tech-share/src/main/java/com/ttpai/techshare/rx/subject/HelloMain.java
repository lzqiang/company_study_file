package com.ttpai.techshare.rx.subject;

import rx.Observable;
import rx.Subscriber;

/**
 * Created by Kail on 2017/11/28.
 */
public class HelloMain {

    public static void main(String[] args) {

        Observable
                .create(new Observable.OnSubscribe<Object>() {
                    @Override
                    public void call(Subscriber<? super Object> subscriber) {
                        System.out.println("asd");
                    }
                })
                .subscribe();


    }

}
