package com.ttpai.techshare.boot.hello.service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.netflix.hystrix.contrib.javanica.conf.HystrixPropertiesManager;
import org.springframework.stereotype.Service;

/**
 * Created by kail on 2017/11/25.
 */
@Service
public class HelloService {

    @HystrixCommand(
            fallbackMethod = "helloFallBack",
            commandProperties = {
//                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
//                    @HystrixProperty(name = "execution.isolation.semaphore.maxConcurrentRequests", value = "2")
                    @HystrixProperty(name = "execution.isolation.strategy", value = "THREAD"),
            }
    )
    public String hello() {
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("hello");
        return "world";
    }


    String helloFallBack() {
        System.out.println("world helloFallBack");
        return "world helloFallBack";
    }

}
