package com.ttpai.techshare.other.observer;

import java.util.Observable;
import java.util.Observer;

/**
 * Created by kail on 2017/11/6.
 */
public class HelloObserve implements Observer {
    @Override
    public void update(Observable o, Object arg) {
        System.out.println("Hello: " + arg);
    }
}