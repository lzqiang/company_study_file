package com.ttpai.techshare.threadpool;

import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.TimeUnit;

/**
 * Java 多线程中的任务分解机制-ForkJoinPool详解
 * http://blog.csdn.net/a369414641/article/details/48350795
 * <p>
 * 聊聊并发（八）——Fork/Join框架介绍
 * http://www.infoq.com/cn/articles/fork-join-introduction/
 * <p>
 * Created by kail on 2017/11/26.
 */
public class ForkJoinPoolActionMain {


    /**
     * 定义一个可分解的的任务类，继承了RecursiveAction抽象类
     * 必须实现它的compute方法
     */
    public static class MyTask extends RecursiveAction {

        private static final long serialVersionUID = 1L;
        //定义一个分解任务的阈值——50,即一个任务最多承担50个工作量
        int THRESHOLD = 50;
        //任务量
        int taskNum = 0;

        MyTask(int Num) {
            this.taskNum = Num;
        }

        @Override
        protected void compute() {
            if (taskNum <= THRESHOLD) {
                System.out.println(Thread.currentThread().getName() + "承担了" + taskNum + "份工作");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } else {
                //随机解成两个任务
                Random m = new Random();
                int x = m.nextInt(50);

                MyTask left = new MyTask(x);
                MyTask right = new MyTask(taskNum - x);

                left.fork();
                right.fork();
            }
        }
    }

    public static void main(String[] args) throws Exception {
        //创建一个支持分解任务的线程池ForkJoinPool
        ForkJoinPool pool = new ForkJoinPool();

        MyTask task = new MyTask(2000);
        pool.submit(task);
        pool.awaitTermination(20, TimeUnit.SECONDS);//等待20s，观察结果
        pool.shutdown();
    }

//    ForkJoinPool-1-worker-3承担了16份工作
//    ForkJoinPool-1-worker-0承担了4份工作  20


//    ForkJoinPool-1-worker-1承担了38份工作
//    ForkJoinPool-1-worker-3承担了32份工作 70

//    ForkJoinPool-1-worker-0承担了43份工作
//    ForkJoinPool-1-worker-2承担了44份工作
//    ForkJoinPool-1-worker-2承担了23份工作 110

}
