package com.ttpai.techshare.threadpool;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.*;

/**
 * Java 多线程中的任务分解机制-ForkJoinPool详解
 * http://blog.csdn.net/a369414641/article/details/48350795
 * <p>
 * Created by kail on 2017/11/26.
 */
public class WorkStealingPoolMain {

    public static void main(String[] args) throws IOException {
        int cpuCount = Runtime.getRuntime().availableProcessors();
        System.out.println(cpuCount);

        ExecutorService executorService = Executors.newWorkStealingPool(cpuCount);

        for (int i = 1; i <= 100; i++) {
            final int count = i;
            Future<?> submit = executorService.submit(new Runnable() {
                @Override
                public void run() {
                    Date now = new Date();
                    System.out.println("线程" + Thread.currentThread().getName() + "完成任务："
                            + count + "   时间为：" + now.getSeconds());
                    try {
                        Thread.sleep(1000);//此任务耗时1s
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            });

        }


        System.in.read();


    }


}
