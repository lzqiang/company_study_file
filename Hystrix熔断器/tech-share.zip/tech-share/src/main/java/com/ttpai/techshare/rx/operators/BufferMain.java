package com.ttpai.techshare.rx.operators;

import rx.Observable;
import rx.Observer;

import java.util.List;

/**
 * Created by Kail on 2017/11/28.
 */
public class BufferMain {

    public static void main(String[] args) {
        Observable.range(0, 30).buffer(10).subscribe(new Observer<List<Integer>>() {
            @Override
            public void onCompleted() {
                System.out.println("onCompleted");
            }

            @Override
            public void onError(final Throwable e) {
                System.err.println("onError: " + e);
            }

            @Override
            public void onNext(final List<Integer> i) {
                System.out.println("onNext: " + i);
            }
        });
    }

}
