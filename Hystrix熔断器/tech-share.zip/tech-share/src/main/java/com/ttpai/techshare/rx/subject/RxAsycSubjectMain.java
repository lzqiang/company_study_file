package com.ttpai.techshare.rx.subject;

import rx.functions.Action1;
import rx.subjects.AsyncSubject;

import java.io.IOException;

/**
 * Created by Kail on 2017/11/28.
 */
public class RxAsycSubjectMain {

    public static void main(String[] args) throws IOException {
        AsyncSubject<String> behaviorSubject = AsyncSubject.create();

        behaviorSubject.subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                System.out.println(s);
            }
        });

        behaviorSubject.onNext("asdasd");
        behaviorSubject.onNext("asdasd");
        behaviorSubject.onNext("asdasd");
        behaviorSubject.onNext("asdasd");
        behaviorSubject.onNext("asdasd");
        behaviorSubject.onCompleted();

        System.in.read();
    }

}
