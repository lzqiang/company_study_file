
RxJava 中文文档 ： https://github.com/mcxiaoke/RxDocs/tree/master/operators

背压(Backpressure)机制 ： http://www.cnblogs.com/iceTing/p/6238207.html

Backpressure ： https://github.com/ReactiveX/RxJava/wiki/Backpressure

RxJava for easy concurrency and backpressure ： https://zeroturnaround.com/rebellabs/rxjava-for-easy-concurrency-and-backpressure/