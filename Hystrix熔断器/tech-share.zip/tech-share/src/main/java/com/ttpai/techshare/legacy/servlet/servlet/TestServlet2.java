package com.ttpai.techshare.legacy.servlet.servlet;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class TestServlet2 extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter writer = resp.getWriter();

        String testServlet2 = new HystrixCommand<String>(HystrixCommandGroupKey.Factory.asKey("TestServlet2")) {
            @Override
            protected String run() throws Exception {
                return "TestServlet2 servlet";
            }
        }.execute();
        writer.write(testServlet2);

        writer.close();
        writer.close();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }
}