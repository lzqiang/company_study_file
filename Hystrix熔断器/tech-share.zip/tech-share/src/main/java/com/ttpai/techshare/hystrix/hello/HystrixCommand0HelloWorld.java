package com.ttpai.techshare.hystrix.hello;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.ttpai.techshare.utils.NetRequestUtil;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public class HystrixCommand0HelloWorld extends HystrixCommand<String> {

    private final String name;

    public HystrixCommand0HelloWorld(String name) {
        super(HystrixCommandGroupKey.Factory.asKey("HystrixCommandHelloWorld"));
        this.name = name;
    }

    @Override
    protected String run() {
        // 假设这里是一个 第三方 的 网络调用，比较耗时

        System.out.println("start");
        NetRequestUtil.request(500);
        System.out.println("end");

        return "Hello " + name + "!";
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException, TimeoutException, IOException {
        // ============================================================================== execute 同步调用
        String result = new HystrixCommand0HelloWorld("Kail").execute(); // cmd.queue().get()
        System.out.println(result);

        // ============================================================================== queue 异步调用

//        Future<String> future = new HystrixCommandHelloWorld("Kail2").queue();
//        System.out.println(future.get());

//        Future<String> future3 = new HystrixCommandHelloWorld("Kail3").queue();
//        System.out.println(future3.get(50, TimeUnit.MILLISECONDS));

        // ============================================================================== observe 异步调用

//        Observable<String> hotObservable = new HystrixCommandHelloWorld("Kail4").observe();
//        String single = hotObservable.toBlocking().single();
//        System.out.println(single);
//        System.in.read();
        // ==============================================================================

//        Observable<String> coldObservable = new HystrixCommandHelloWorld("Kail5").toObservable();
//        coldObservable.subscribe(new Action1<String>() {
//            @Override
//            public void call(String s) {
//                System.out.println(s);
//            }
//        });
//        System.in.read();

    }
}
/**
 * 一个"热"的Observable典型的只要一创建完就开始发射数据，因此所有后续订阅它的观察者可能从序列中间的某个位置开始接受数据（有一些数据错过了）。
 * 一个"冷"的Observable会一直等待，直到有观察者订阅它才开始发射数据，因此这个观察者可以确保会收到整个数据序列。
 */