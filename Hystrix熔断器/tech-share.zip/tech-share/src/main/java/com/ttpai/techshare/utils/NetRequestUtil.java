package com.ttpai.techshare.utils;

import java.util.concurrent.TimeUnit;

/**
 * Created by kail on 2017/11/29.
 */
public class NetRequestUtil {

    public static void request(int time) {
        try {
            TimeUnit.MILLISECONDS.sleep(time);
        } catch (InterruptedException e) {
//            e.printStackTrace();
        }
    }

    public static void sleep(int time) {
        try {
            TimeUnit.MILLISECONDS.sleep(time);
        } catch (InterruptedException e) {
//            e.printStackTrace();
        }
    }

}
