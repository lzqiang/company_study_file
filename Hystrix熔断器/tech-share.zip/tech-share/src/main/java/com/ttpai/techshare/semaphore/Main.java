package com.ttpai.techshare.semaphore;

/**
 * Created by kail on 2017/11/5.
 */
public class Main {

    public static void main(String[] args) throws InterruptedException {
        SemaphoreDemo1 semaphoreDemo = new SemaphoreDemo1();
//        SemaphoreDemo2 semaphoreDemo = new SemaphoreDemo2();
//        SemaphoreDemo3 semaphoreDemo = new SemaphoreDemo3();
//        SemaphoreDemo4 semaphoreDemo = new SemaphoreDemo4();

        Thread threadA = new Thread(semaphoreDemo::doit);
        threadA.setName("A");

        threadA.start();

        Thread threadB = new Thread(semaphoreDemo::doit);
        threadB.setName("B");
        threadB.start();

//        TimeUnit.MILLISECONDS.sleep(1);
//        threadB.interrupt();
//        System.out.println("main中断了 B");
    }

}
