package com.ttpai.techshare.hystrix.hello;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.ttpai.techshare.utils.NetRequestUtil;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public class HystrixCommand2FallBack extends HystrixCommand<String> {

    private final String name;

    public HystrixCommand2FallBack(String name) {
        super(HystrixCommandGroupKey.Factory.asKey("HystrixCommandHelloWorld"));
        this.name = name;
    }

    @Override
    protected String run() {
        // 假设这里是一个 第三方 的 网络调用，比较耗时
        System.out.println("start");
        NetRequestUtil.request(1500); // 变动在这里，改为1500
        System.out.println("end");

        return "Hello " + name + "!";
    }

    @Override
    protected String getFallback() {
        return "Hello Default";
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException, TimeoutException, IOException {
        String result = new HystrixCommand2FallBack("Kail").execute(); // cmd.queue().get()
        System.out.println(result);


    }
}
