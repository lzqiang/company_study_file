package com.ttpai.techshare.semaphore;

import java.util.concurrent.Semaphore;

/**
 * Created by kail on 2017/11/5.
 */
public class SemaphoreDemo2 {

    private Semaphore semaphore = new Semaphore(1);

    public void doit() {
        try {

            semaphore.acquireUninterruptibly();
            System.out.println(Thread.currentThread().getName() + " begin timer=" + System.currentTimeMillis());
            for (int i = 0; i < Integer.MAX_VALUE; i++) {
            }
            System.out.println(Thread.currentThread().getName() + "   end timer=" + System.currentTimeMillis());

        } finally {
            System.out.println(semaphore.availablePermits() + "--" + semaphore.drainPermits());
            semaphore.release();
            System.out.println(semaphore.availablePermits() + "--" + semaphore.drainPermits());
            semaphore.release();
            System.out.println(semaphore.availablePermits() + "--" + semaphore.drainPermits());
            semaphore.release();
            System.out.println(semaphore.availablePermits() + "--" + semaphore.drainPermits());
            semaphore.release();
            System.out.println(semaphore.availablePermits() + "--" + semaphore.drainPermits());
        }
    }

}
