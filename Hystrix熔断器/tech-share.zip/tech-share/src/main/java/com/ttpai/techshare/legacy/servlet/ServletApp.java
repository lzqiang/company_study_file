package com.ttpai.techshare.legacy.servlet;

import com.google.common.collect.Lists;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;

/**
 * spring boot注入servlet : http://www.cnblogs.com/java-zhao/p/5775103.html
 * <p>
 * Created by kail on 2017/11/25.
 */
@SpringBootApplication
public class ServletApp {

    public static void main(String[] args) {
        ArrayList<String> argsList = Lists.newArrayList(args);
        argsList.add("--server.port=9005");

        SpringApplication.run(ServletApp.class, argsList.toArray(new String[argsList.size()]));

    }
}
