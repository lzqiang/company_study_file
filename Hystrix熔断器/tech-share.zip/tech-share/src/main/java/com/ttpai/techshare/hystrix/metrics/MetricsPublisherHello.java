package com.ttpai.techshare.hystrix.metrics;

import com.netflix.hystrix.*;
import com.netflix.hystrix.strategy.metrics.HystrixMetricsPublisher;
import com.netflix.hystrix.strategy.metrics.HystrixMetricsPublisherCommand;

/**
 * Created by kail on 2017/11/30.
 */
public class MetricsPublisherHello extends HystrixMetricsPublisher {

    @Override
    public HystrixMetricsPublisherCommand getMetricsPublisherForCommand(HystrixCommandKey commandKey, HystrixCommandGroupKey commandGroupKey, HystrixCommandMetrics metrics, HystrixCircuitBreaker circuitBreaker, HystrixCommandProperties properties) {



        return new MetricsPublisherCommand(commandKey, commandGroupKey, metrics, circuitBreaker, properties);
    }

    public static void main(String[] args) {

    }

}
