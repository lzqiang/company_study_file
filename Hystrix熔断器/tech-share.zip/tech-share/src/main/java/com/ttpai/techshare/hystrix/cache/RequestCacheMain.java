package com.ttpai.techshare.hystrix.cache;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;

/**
 * https://github.com/Netflix/Hystrix/wiki/How-To-Use#request-cache
 * <p>
 * Created by kail on 2017/11/30.
 */
public class RequestCacheMain extends HystrixCommand<String> {
    private String data;

    public RequestCacheMain(String data) {
        super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("RequestCacheMain")));
        this.data = data;
    }

    @Override
    protected String run() throws Exception {
        System.out.println(commandState.get() + "  status"); // command 状态
        return data + " World!";
    }

    @Override
    protected String getCacheKey() {
        return data;
    }

    public static void main(String[] args) {
        HystrixRequestContext context = HystrixRequestContext.initializeContext();
        try {
            System.out.println(new RequestCacheMain("Hello").execute());
            System.out.println(new RequestCacheMain("Hi").execute());
            System.out.println(new RequestCacheMain("Hello").execute());
        } finally {
            context.shutdown();
        }
    }
}
