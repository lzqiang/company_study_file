package com.ttpai.techshare.boot.hello.controller;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.ttpai.techshare.boot.hello.service.HelloService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * Created by Kail on 2017/11/23.
 */
@RestController
@RequestMapping("/hello")
public class HelloController {

    @Resource
    private HelloService helloService;

    @RequestMapping("/index")
    public String index() {

        return new HystrixCommand<String>(HystrixCommandGroupKey.Factory.asKey("HelloController")) {
            @Override
            protected String run() throws Exception {
                return "ok";
            }
        }.execute();
    }


    @RequestMapping("/index2")
    public String index2() {
        return helloService.hello();
    }


}
