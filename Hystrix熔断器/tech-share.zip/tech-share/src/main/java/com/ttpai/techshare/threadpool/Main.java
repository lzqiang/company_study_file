package com.ttpai.techshare.threadpool;

import java.util.concurrent.*;

/**
 * Created by kail on 2017/11/6.
 * <p>
 * http://blog.csdn.net/a369414641/article/details/48342253
 * http://ifeve.com/java8-concurrency-tutorial-thread-executor-examples/
 */
public class Main {

    public static void main(String[] args) throws Exception {
//        ExecutorService executorService = Executors.newFixedThreadPool(2);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
//        ExecutorService executorService = Executors.newWorkStealingPool(2);
//        ExecutorService executorService = Executors.newCachedThreadPool();

        Callable<Object> callable = Executors.callable(() -> {
            System.out.println("do something");
            try {
                TimeUnit.SECONDS.sleep(2);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("end");
        });

        Future<Object> submit1 = executorService.submit(callable);
        Object o = null;
        try {

            o = submit1.get(1, TimeUnit.SECONDS);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        System.out.println(o);

        Thread end = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("do something");
                for (int i=0;i<Integer.MAX_VALUE;i++){

                }
                System.out.println("end");
            }
        });
        end.start();

        TimeUnit.MILLISECONDS.sleep(1);

//        end.interrupt();
        end.stop();


//        System.out.println("submit1");
//        Future<Object> submit2 = executorService.submit(callable);
//        System.out.println("submit2");
//        Future<Object> submit3 = executorService.submit(callable);
//        System.out.println("submit3");
//        Future<Object> submit4 = executorService.submit(callable);
//        System.out.println("submit4");
//        System.out.println("=======================");
//
//        submit4.get(1,TimeUnit.DAYS);


        executorService.shutdown();
    }

}
