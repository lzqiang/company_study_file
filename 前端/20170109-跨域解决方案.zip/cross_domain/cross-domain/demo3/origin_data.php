<?php 

	echo "我是远程server";

 ?>