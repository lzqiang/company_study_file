
   function getServerData(jsondata){
        //处理获得的json数据
    }